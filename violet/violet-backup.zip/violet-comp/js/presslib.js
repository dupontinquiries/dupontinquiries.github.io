
$(document).keypress(function(e) {
  console.log(e.which);
  // 104 h
  // 117 u
  // 112 p
  // 0 48
  // 1 50
  // ...
  // 9 57
  // if(e.which == 13) {
  //   // enter pressed
  // }
});
